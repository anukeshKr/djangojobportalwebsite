from django.contrib import admin
from .models import Resume
# Register your models here.
admin.site.register(Resume)