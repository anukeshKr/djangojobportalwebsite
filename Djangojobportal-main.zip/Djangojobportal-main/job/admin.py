from django.contrib import admin
from .models import Industry,State
# Register your models here.

admin.site.register(Industry)
admin.site.register(State)